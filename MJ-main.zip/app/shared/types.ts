/**
 * 共享类型定义
 *
 * 本文件定义前后端共用的核心类型，确保类型一致性。
 * 任何涉及模型配置、任务状态的功能都应引用此文件。
 */

// ==================== 模型分类 ====================

/**
 * 模型分类
 * - 用于区分绘图模型、对话模型和视频模型
 * - 使用场景：模型配置表单、模型列表筛选
 */
export type ModelCategory = 'image' | 'chat' | 'video'

// ==================== 绘图相关类型 ====================

/**
 * 支持的绘图模型类型
 * - 用于标识不同的图像生成服务
 * - 使用场景：任务创建、模型配置、任务卡片显示
 */
export type ImageModelType =
  | 'midjourney'   // Midjourney，支持 U/V 操作
  | 'gemini'       // Google Gemini 绘图
  | 'flux'         // Flux 图像生成
  | 'dalle'        // OpenAI DALL-E
  | 'doubao'       // 字节豆包
  | 'gpt4o-image'  // GPT-4o 图像生成
  | 'gpt-image'    // GPT Image 系列（gpt-image-1, gpt-image-1.5）
  | 'sora-image'   // Sora 图像生成
  | 'grok-image'   // xAI Grok 图像生成
  | 'qwen-image'   // 阿里通义万相
  | 'z-image'      // Gitee AI Z-Image
  | 'koukoutu'     // 抠抠图（背景移除）
  | 'nanobanana'   // NanoBanana 绘图
  | 'nanobanana-pro'   // NanoBanana Pro 绘图
  | 'nanobanana-2' // NanoBanana 2 绘图

// ==================== 对话相关类型 ====================

/**
 * 支持的对话模型类型
 * - 用于标识不同的对话服务
 * - 使用场景：助手配置、对话消息发送
 */
export type ChatModelType =
  | 'gpt'          // OpenAI GPT 系列
  | 'claude'       // Anthropic Claude 系列
  | 'gemini-chat'  // Google Gemini 对话
  | 'deepseek'     // DeepSeek
  | 'qwen-chat'    // 阿里通义千问
  | 'grok'         // xAI Grok 系列
  | 'llama'        // Meta LLaMA 系列
  | 'moonshot'     // 月之暗面 Kimi
  | 'glm'          // 智谱 GLM 系列
  | 'doubao-chat'  // 字节豆包对话
  | 'minimax'      // MiniMax
  | 'hunyuan'      // 腾讯混元
  | 'mixtral'      // Mistral Mixtral
  | 'phi'          // Microsoft Phi

// ==================== 视频相关类型 ====================

/**
 * 支持的视频模型类型
 * - 用于标识不同的视频生成服务
 * - 使用场景：任务创建、模型配置、任务卡片显示
 */
export type VideoModelType =
  | 'jimeng-video'  // 即梦视频
  | 'veo'           // Google Veo
  | 'sora'          // OpenAI Sora
  | 'grok-video'    // xAI Grok Video

/**
 * 所有模型类型的联合
 * - 使用场景：模型配置表单中选择模型类型
 */
export type ModelType = ImageModelType | ChatModelType | VideoModelType

// ==================== 模型能力类型 ====================

/**
 * 模型能力
 * - vision: 视觉能力（支持图片输入）
 * - reasoning: 推理能力（深度思考）
 * - function_calling: 工具调用能力
 * - web_search: 联网搜索能力
 */
export type ModelCapability = 'vision' | 'reasoning' | 'function_calling' | 'web_search'

/**
 * 模型前端 UI 能力配置
 * - 用于控制前端表单显示哪些选项
 * - 存储在 aimodels.uiCapabilities 字段
 */
export interface ModelUICapabilities {
  /** 支持的宽高比列表（图片/视频模型） */
  aspectRatios?: string[]
  /** 支持的尺寸列表（图片模型） */
  sizes?: string[]
  /** 是否支持负面提示词 */
  negativePrompt?: boolean
  /** 是否支持质量参数 */
  quality?: boolean
  /** 是否支持风格参数 */
  style?: boolean
  /** 是否支持随机种子 */
  seed?: boolean
  /** 是否支持提示词相关度 */
  guidance?: boolean
  /** 是否支持水印 */
  watermark?: boolean
  /** 是否支持背景透明度 */
  background?: boolean
  /** 是否支持联网搜索（对话模型） */
  webSearch?: boolean
  /** 是否支持深度思考（对话模型） */
  deepThinking?: boolean
  /** 支持的思考模式列表 */
  thinkingModes?: ('fast' | 'medium' | 'deep')[]
  /** 是否支持参考图（图片模型） */
  referenceImage?: boolean
  /** 是否支持提示词增强（视频模型） */
  enhancePrompt?: boolean
  /** 是否支持超分辨率（视频模型） */
  enableUpsample?: boolean
  /** 支持的时长选项（视频模型，秒） */
  durations?: number[]
}

// ==================== API 格式类型 ====================

/**
 * 支持的 API 请求格式
 * - 不同中转站可能使用不同的 API 格式
 * - 使用场景：任务创建时选择请求格式、服务层路由
 */
export type ApiFormat =
  | 'mj-proxy'       // MJ-Proxy 格式，用于 Midjourney
  | 'gemini'         // Google Gemini API 原生格式
  | 'nanobanana'     // NanoBanana API 格式（Gemini 原生图像生成）
  | 'dalle'          // OpenAI DALL-E Images API 格式
  | 'openai-chat'    // OpenAI Chat Completions API 格式
  | 'openai-response' // OpenAI Response API 格式（优先用于 OpenAI 模型）
  | 'claude'         // Anthropic Claude Messages API 格式
  | 'koukoutu'       // 抠抠图 API 格式（异步轮询）
  | 'video-unified'  // 视频统一格式（/v1/video/create），用于即梦、Veo
  | 'openai-video'   // OpenAI Video 格式（/v1/videos），用于 Sora

// ==================== 任务类型 ====================

/**
 * 任务类型
 * - 用于区分图片任务和视频任务
 * - 使用场景：任务创建、任务列表筛选、卡片渲染
 */
export type TaskType = 'image' | 'video'

// ==================== 任务状态类型 ====================

/**
 * 任务状态
 * - 用于追踪任务的生命周期（图片和视频共用）
 * - 使用场景：任务列表显示、状态轮询、进度条控制
 */
export type TaskStatus =
  | 'pending'      // 等待提交
  | 'submitting'   // 正在提交到上游
  | 'processing'   // 上游处理中
  | 'success'      // 生成成功
  | 'failed'       // 生成失败
  | 'cancelled'    // 已取消

// ==================== 消息角色类型 ====================

/**
 * 消息角色
 * - 用于标识对话消息的发送者
 * - 使用场景：对话历史显示、消息列表渲染
 */
export type MessageRole = 'user' | 'assistant' | 'system'

/**
 * 工具调用记录（存储在 assistant 消息的 toolCalls 字段）
 * - 每个记录对应一次工具调用及其结果
 */
export interface ToolCallRecord {
  /** tool_use_id，用于关联请求和结果 */
  id: string
  /** MCP 服务 ID */
  serverId: number
  /** MCP 服务名称 */
  serverName: string
  /** 工具原始名称 */
  toolName: string
  /** 工具显示名称（mcp__{server}__{tool} 格式，用于 AI 模型识别） */
  displayName: string
  /** 工具调用参数 */
  arguments: Record<string, unknown>
  /** 调用状态 */
  status: 'pending' | 'invoking' | 'done' | 'error' | 'cancelled'
  /** 工具返回结果 */
  response?: unknown
  /** 是否为错误结果 */
  isError?: boolean
}

/**
 * 消息标记
 * - 用于标识特殊类型的消息
 * - 使用场景：错误消息、压缩消息的识别
 */
export type MessageMark = 'error' | 'compress-request' | 'compress-response' | 'system-prompt'

/**
 * AI 消息状态
 * - 用于追踪 AI 消息的生成生命周期
 * - 用户消息的 status 为 null
 */
export type MessageStatus =
  | 'created'    // 已创建，尚未发起上游请求
  | 'pending'    // 已发起上游请求，等待响应
  | 'streaming'  // 正在接收流式输出
  | 'completed'  // 生成完成
  | 'stopped'    // 用户中断
  | 'failed'     // 生成失败

// ==================== 消息文件类型 ====================

/**
 * 消息附件文件
 * - 用于存储对话消息中的文件信息
 * - 使用场景：多模态对话、文件上传
 */
export interface MessageFile {
  /** 原始文件名 */
  name: string
  /** 存储文件名（服务器生成的唯一名称） */
  fileName: string
  /** MIME 类型 */
  mimeType: string
  /** 文件大小（字节） */
  size: number
  /** 公网访问 URL（用于 API 请求时替代 base64） */
  publicUrl?: string
}

// ==================== 上游平台类型 ====================

/**
 * 上游平台类型
 * - 用于标识上游 API 平台，便于余额查询等功能
 * - oneapi: OneAPI/NewAPI 格式，GET /api/user/self
 */
export type UpstreamPlatform = 'oneapi' | 'n1n' | 'yunwu'

/**
 * 上游信息缓存
 * - 存储从上游 API 查询到的用户信息
 * - 使用场景：余额显示、用户信息展示
 */
export interface UpstreamInfo {
  /** 用户 ID */
  userId?: number
  /** 用户名 */
  username?: string
  /** 显示名称 */
  displayName?: string
  /** 邮箱 */
  email?: string
  /** 原始配额 */
  quota?: number
  /** 已用配额 */
  usedQuota?: number
  /** 是否无限额度 */
  unlimitedQuota?: boolean
  /** 用户组 */
  group?: string
  /** 查询时间 */
  queriedAt?: string
}

// ==================== API Key 配置 ====================

/**
 * API Key 配置
 * - 用于存储上游的多个 API Key
 * - 使用场景：模型配置中的多 Key 管理
 */
export interface ApiKeyConfig {
  /** Key 名称，如 "default", "premium", "backup" */
  name: string
  /** API Key 值 */
  key: string
}

// ==================== 模型参数类型 ====================

/**
 * 生图模型参数
 * - 适用于 MJ-Proxy、DALL-E、Gemini、OpenAI Chat 等格式
 */
export interface ImageModelParams {
  /** 负面提示词（MJ、Flux） */
  negativePrompt?: string
  /** 尺寸：1024x1024 或 1K/2K/4K（DALL-E、GPT-Image、豆包、Gemini） */
  size?: string
  /** 宽高比：16:9 等（Flux、Gemini） */
  aspectRatio?: string
  /** 生成数量：1-10 */
  n?: number
  /** 随机种子（豆包） */
  seed?: number
  /** 质量（DALL-E 3: standard/hd，GPT Image: high/medium/low） */
  quality?: 'standard' | 'hd' | 'high' | 'medium' | 'low'
  /** 风格（DALL-E 3） */
  style?: 'vivid' | 'natural'
  /** 提示词相关度：1-10（豆包） */
  guidanceScale?: number
  /** 水印（豆包） */
  watermark?: boolean
  /** 机器人类型（MJ） */
  botType?: 'MID_JOURNEY' | 'NIJI_JOURNEY'
  /** 背景透明度（GPT Image） */
  background?: 'auto' | 'transparent' | 'opaque'
  /** 思考模式（Gemini） */
  thinkingMode?: 'fast' | 'medium' | 'deep'
  /** 启用联网搜索（Gemini） */
  webSearch?: boolean
  /** 启用图片搜索（Gemini） */
  imageSearch?: boolean
}

/**
 * 即梦视频参数
 */
export interface JimengVideoParams {
  /** 宽高比：16:9, 9:16, 4:3, 3:4, 1:1, 21:9 */
  aspectRatio?: string
  /** 分辨率：1080P、1280x720、720x1280 */
  size?: string
}

/**
 * Veo 视频参数
 */
export interface VeoVideoParams {
  /** 宽高比：16:9, 9:16 */
  aspectRatio?: string
  /** 提示词增强 */
  enhancePrompt?: boolean
  /** 超分辨率 */
  enableUpsample?: boolean
  /** 图片模式 */
  imageMode?: 'reference' | 'frames' | 'components'
}

/**
 * Sora 视频参数
 */
export interface SoraVideoParams {
  /** 方向（替代宽高比） */
  orientation?: 'portrait' | 'landscape'
  /** 分辨率（必填） */
  size: 'small' | 'large'
  /** 时长：10、15 等 */
  duration?: number
  /** 水印 */
  watermark?: boolean
  /** 隐私模式 */
  private?: boolean
}

/**
 * Grok Video 参数
 */
export interface GrokVideoParams {
  /** 宽高比：2:3, 3:2, 1:1 */
  aspectRatio?: string
  /** 分辨率：720P */
  size?: string
}

/**
 * 视频模型参数（统一接口，用于 videoUnified provider）
 */
export interface VideoModelParams {
  aspectRatio?: string
  size?: string
  enhancePrompt?: boolean
  enableUpsample?: boolean
  orientation?: 'portrait' | 'landscape'
  duration?: number
  watermark?: boolean
}

/**
 * 模型参数联合类型
 * - 使用场景：任务创建、表单提交
 */
export type ModelParams =
  | ImageModelParams
  | JimengVideoParams
  | VeoVideoParams
  | SoraVideoParams
  | GrokVideoParams

// ==================== 模型类型配置接口 ====================

/**
 * 模型类型配置
 * - 描述一个上游配置中支持的单个模型
 * - 使用场景：模型配置存储、绘图面板模型选择、设置页面模型配置编辑
 */
export interface ModelTypeConfig {
  /** 模型分类，默认 'image' 兼容旧数据 */
  category?: ModelCategory
  /** 界面显示的模型类型 */
  modelType: ModelType
  /** 实际请求时使用的 API 格式 */
  apiFormat: ApiFormat
  /** 发送给上游的模型标识符 */
  modelName: string
  /** 预计时间（秒）：绘图模型为预计生成时间，对话模型为预计首字时长 */
  estimatedTime?: number
  /** 使用的 Key 名称，默认 "default" */
  keyName?: string
}

// ==================== 认证用户类型 ====================

/**
 * 用户角色类型
 * - admin: 管理员（账号密码登录）
 * - user: 普通用户（API Key 登录）
 */
export type UserRole = 'admin' | 'user'

/**
 * 认证用户信息
 * - 用于 JWT payload 和前端用户状态
 * - 使用场景：登录、用户信息显示
 */
export interface AuthUser {
  id: number
  username?: string | null
  email?: string | null
  name: string | null
  avatar?: string | null
  role: UserRole
}

// ==================== AI 模型输入类型 ====================

/**
 * AI 模型输入（创建/更新时使用）
 * - 使用场景：上游配置表单提交
 */
export interface AimodelInput {
  /** 编辑时的 ID，新建时为空 */
  id?: number
  category: ModelCategory
  modelType: ModelType
  apiFormat: ApiFormat
  modelName: string
  /** 显示名称（用户可自定义） */
  name: string
  /** 模型能力列表 */
  capabilities?: ModelCapability[]
  /** 厂商名称（手动指定，空则自动推断） */
  vendor?: string | null
  /** 前端 UI 能力配置（覆盖默认推断） */
  uiCapabilities?: ModelUICapabilities | null
  estimatedTime?: number
  keyName?: string
  /** 排序顺序 */
  sortOrder?: number
}

// ==================== 分页响应类型 ====================

/**
 * 分页响应
 * - 用于任务列表、回收站等分页接口
 */
export interface PaginatedResponse<T> {
  tasks: T[]
  total: number
  page: number
  pageSize: number
}

// ==================== 任务上游摘要类型 ====================

/**
 * 任务上游摘要（精简版，用于任务列表/详情）
 * - 使用场景：任务卡片、任务详情弹窗
 */
export interface TaskUpstreamSummary {
  name: string
  estimatedTime: number | null
  /** AI 模型的显示名称 */
  aimodelName: string
}

// ==================== 错误处理工具 ====================

/**
 * 从 unknown 类型的错误中提取错误信息
 * - 替代 error: any 模式
 */
export function getErrorMessage(error: unknown): string {
  // 取消操作，用户主动中止
  if (isAbortError(error)) {
    return '用户已取消'
  }
  if (error instanceof Error) {
    return error.message
  }
  if (typeof error === 'string') {
    return error
  }
  if (error && typeof error === 'object' && 'message' in error) {
    return String((error as { message: unknown }).message)
  }
  return '未知错误'
}

/**
 * 检查是否为 abort 错误
 */
export function isAbortError(error: unknown): boolean {
  if (error instanceof Error) {
    return (
      error.name === 'AbortError' ||
      error.message.includes('aborted') ||
      error.message.includes('abort')
    )
  }
  if (error && typeof error === 'object') {
    const e = error as { name?: string; message?: string; cause?: { name?: string } }
    return (
      e.name === 'AbortError' ||
      e.cause?.name === 'AbortError' ||
      e.message?.includes('aborted') ||
      e.message?.includes('abort') ||
      false
    )
  }
  return false
}

/**
 * 从 fetch 错误响应中提取详细信息
 */
export async function getResponseErrorMessage(response: Response): Promise<string> {
  try {
    const data = await response.json()
    if (data && typeof data === 'object') {
      // 尝试多种常见的错误字段
      return data.message || data.error?.message || data.error || data.detail || response.statusText
    }
  } catch {
    // JSON 解析失败，使用 statusText
  }
  return response.statusText || `HTTP ${response.status}`
}

// ==================== MCP 客户端类型 ====================

/** MCP 服务传输类型 */
export type McpServerType = 'sse' | 'streamableHttp' | 'stdio'

/** MCP 服务连接状态 */
export type McpConnectionStatus = 'disconnected' | 'connecting' | 'connected' | 'error'

/** MCP 工具定义 */
export interface McpTool {
  serverId: number
  serverName: string
  name: string
  displayName: string
  description: string
  inputSchema: Record<string, unknown>
  isEnabled: boolean
  isAutoApprove: boolean
}

/** MCP 服务前端展示数据 */
export interface McpServerDisplay {
  id: number
  name: string
  description: string | null
  type: McpServerType
  isActive: boolean
  baseUrl: string | null
  headers: Record<string, string> | null
  timeout: number
  disabledTools: string[]
  autoApproveTools: string[]
  logoUrl: string | null
  // stdio 类型字段
  command: string | null
  args: string[] | null
  env: Record<string, string> | null
  connectionStatus?: McpConnectionStatus
  tools?: McpTool[]
  toolCount?: number
}
